@extends('layouts.user')
@section('content')
    <h2 class="title-bar">
        {{__("Settings")}}
        <a href="{{route('user.change_password')}}" class="btn-change-password">{{__("Change Password")}}</a>
    </h2>
    @include('admin.message')
    <form action="{{route('user.profile.update')}}" method="post" class="input-has-icon">
        @csrf
        <div class="row">
            <div class="col-md-6">
                <div class="form-title">
                    <strong>{{__("Personal Information")}}</strong>
                </div>
                @if($is_vendor_access)
                    <div class="form-group">
                        <label>{{__("Business name")}}</label>
                        <input type="text" value="{{old('business_name',$dataUser->business_name)}}" name="business_name" placeholder="{{__("Business name")}}" class="form-control">
                        <i class="fa fa-user input-icon"></i>
                    </div>
                @endif
                <div class="form-group">
                    <label>{{__("User name")}} <span class="text-danger">*</span></label>
                    <input type="text" required minlength="4" name="user_name" value="{{old('user_name',$dataUser->user_name)}}" placeholder="{{__("User name")}}" class="form-control">
                    <i class="fa fa-user input-icon"></i>
                </div>
                <div class="form-group">
                    <label>{{__("E-mail")}}</label>
                    <input type="text" name="email" value="{{old('email',$dataUser->email)}}" placeholder="{{__("E-mail")}}" class="form-control">
                    <i class="fa fa-envelope input-icon"></i>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>{{__("First name")}}</label>
                            <input type="text" value="{{old('first_name',$dataUser->first_name)}}" name="first_name" placeholder="{{__("First name")}}" class="form-control">
                            <i class="fa fa-user input-icon"></i>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>{{__("Last name")}}</label>
                            <input type="text" value="{{old('last_name',$dataUser->last_name)}}" name="last_name" placeholder="{{__("Last name")}}" class="form-control">
                            <i class="fa fa-user input-icon"></i>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label>{{__("Phone Number")}}</label>
                    <input type="tel" value="{{old('phone',$dataUser->phone)}}" name="phone" placeholder="{{__("Phone Number")}}" class="form-control bravo-intl-phone" autocomplete="tel">
                    <i class="fa fa-phone input-icon"></i>
                </div>
                <div class="form-group">
                    <label>{{__("Whatsapp Number")}}</label>
                    @php
                        $whatsappFull = old('whatsapp_full');
                        if ($whatsappFull === null) {
                            $waCode = preg_replace('/\D/', '', (string) ($dataUser->whatsapp_code ?? ''));
                            $waNum = preg_replace('/\D/', '', (string) ($dataUser->whatsapp ?? ''));
                            $whatsappFull = ($waCode || $waNum) ? '+' . $waCode . $waNum : '';
                        }
                    @endphp
                    <input type="tel" value="{{ $whatsappFull }}" name="whatsapp_full" class="form-control bravo-intl-phone bravo-intl-whatsapp" autocomplete="tel" placeholder="{{ __('Whatsapp Number') }}">
                    <input type="hidden" name="whatsapp_code" value="{{ old('whatsapp_code', $dataUser->whatsapp_code) }}">
                    <input type="hidden" name="whatsapp" value="{{ old('whatsapp', $dataUser->whatsapp) }}">
                    <i class="fa fa-whatsapp input-icon"></i>
                </div>
                <div class="form-group">
                    <label>{{__("Birthday")}}</label>
                    <input type="text" value="{{ old('birthday',$dataUser->birthday? display_date($dataUser->birthday) :'') }}" name="birthday" placeholder="{{__("Birthday")}}" class="form-control date-picker">
                    <i class="fa fa-birthday-cake input-icon"></i>
                </div>
                <div class="form-group">
                    <label>{{__("About Yourself")}}</label>
                    <textarea name="bio" rows="5" class="form-control">{{old('bio',$dataUser->bio)}}</textarea>
                </div>
                <div class="form-group">
                    <label>{{__("Avatar")}}</label>
                    <div class="upload-btn-wrapper">
                        <div class="input-group">
                            <span class="input-group-btn">
                                <span class="btn btn-default btn-file">
                                    {{__("Browse")}}… <input type="file">
                                </span>
                            </span>
                            <input type="text" data-error="{{__("Error upload...")}}" data-loading="{{__("Loading...")}}" class="form-control text-view" readonly value="{{ get_file_url( old('avatar_id',$dataUser->avatar_id) ) ?? $dataUser->getAvatarUrl()?? __("No Image")}}">
                        </div>
                        <input type="hidden" class="form-control" name="avatar_id" value="{{ old('avatar_id',$dataUser->avatar_id)?? ""}}">
                        <img class="image-demo" src="{{ get_file_url( old('avatar_id',$dataUser->avatar_id) ) ??  $dataUser->getAvatarUrl() ?? ""}}"/>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-title">
                    <strong>{{__("Location Information")}}</strong>
                </div>
                <div class="form-group">
                    <label>{{__("Address Line 1")}}</label>
                    <input type="text" value="{{old('address',$dataUser->address)}}" name="address" id="customPlaceAddress" placeholder="{{__("Address")}}" class="form-control">
                    <i class="fa fa-location-arrow input-icon"></i>
                </div>
                <div class="form-group">
                    <label>{{__("Address Line 2")}}</label>
                    <input type="text" value="{{old('address2',$dataUser->address2)}}" name="address2" placeholder="{{__("Address2")}}" class="form-control">
                    <i class="fa fa-location-arrow input-icon"></i>
                </div>
                <div class="form-group">
                    <label>{{__("City")}}</label>
                    <input type="text" value="{{old('city',$dataUser->city)}}" name="city" placeholder="{{__("City")}}" class="form-control">
                    <i class="fa fa-street-view input-icon"></i>
                </div>
                <div class="form-group">
                    <label>{{__("State")}}</label>
                    <input type="text" value="{{old('state',$dataUser->state)}}" name="state" placeholder="{{__("State")}}" class="form-control">
                    <i class="fa fa-map-signs input-icon"></i>
                </div>
                <div class="form-group">
                    <label>{{__("Country")}}</label>
                    <select name="country" class="form-control">
                        <option value="">{{__('-- Select --')}}</option>
                        @foreach(get_country_lists() as $id=>$name)
                            <option @if((old('country',$dataUser->country ?? '')) == $id) selected @endif value="{{$id}}">{{$name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label>{{__("Zip Code")}}</label>
                    <input type="text" value="{{old('zip_code',$dataUser->zip_code)}}" name="zip_code" placeholder="{{__("Zip Code")}}" class="form-control">
                    <i class="fa fa-map-pin input-icon"></i>
                </div>
                <div class="form-group">
                    <label class="control-label">{{__("The geographic coordinate")}}</label>
                    <div class="control-map-group">
                        <div id="map_content"></div>
                        <input type="text" placeholder="{{__("Search by name...")}}" class="bravo_searchbox form-control" autocomplete="off" onkeydown="return event.key !== 'Enter';">
                        <div class="g-control">
                            <div class="form-group">
                                <label>{{__("Map Latitude")}}:</label>
                                <input type="text" name="map_lat" class="form-control" value="{{old('map_lat',$dataUser->map_lat)}}" onkeydown="return event.key !== 'Enter';">
                            </div>
                            <div class="form-group">
                                <label>{{__("Map Longitude")}}:</label>
                                <input type="text" name="map_lng" class="form-control" value="{{old('map_lng',$dataUser->map_lng)}}" onkeydown="return event.key !== 'Enter';">
                            </div>
                            <div class="form-group">
                                <label>{{__("Map Zoom")}}:</label>
                                <input type="text" name="map_zoom" class="form-control" value="{{old('map_zoom',$dataUser->map_zoom ?? 18)}}" onkeydown="return event.key !== 'Enter';">
                            </div>
                        </div>
                    </div>
                    <div class="map-google-url-field mt-3">
                        <label>{{__("Google Maps place link")}}</label>
                        <input type="url" name="map_google_url" class="form-control" value="{{old('map_google_url',$dataUser->map_google_url)}}" placeholder="https://www.google.com/maps/place/...">
                        <p class="help-block">{{__('Paste the full link from Google Maps → Share → Copy link (opens the exact business pin).')}}</p>
                    </div>
                </div>

                <div class="form-group">
                    <label>{{__("Website")}}</label>
                    <input type="text" value="{{old('website',$dataUser->website)}}" name="website" placeholder="{{__("Website")}}" class="form-control">
                    <i class="fa fa-globe input-icon"></i>
                </div>   

                
                <div class="form-group">
                    <label>{{__("Facebook")}}</label>
                    <input type="text" value="{{old('facebook',$dataUser->facebook)}}" name="facebook" placeholder="{{__("Facebook")}}" class="form-control">
                    <i class="fa fa-facebook input-icon"></i>
                </div>    
                
                <div class="form-group">
                    <label>{{__("Linkedin")}}</label>
                    <input type="text" value="{{old('linkedin',$dataUser->linkedin)}}" name="linkedin" placeholder="{{__("Linkedin")}}" class="form-control">
                    <i class="fa fa-linkedin input-icon"></i>
                </div>                


                <div class="form-group">
                    <label>{{__("Instagram")}}</label>
                    <input type="text" value="{{old('instagram',$dataUser->instagram)}}" name="instagram" placeholder="{{__("Instagram")}}" class="form-control">
                    <i class="fa fa-instagram input-icon"></i>
                </div>                


                <div class="form-group">
                    <label>{{__("Youtube")}}</label>
                    <input type="text" value="{{old('youtube',$dataUser->youtube)}}" name="youtube" placeholder="{{__("Youtube")}}" class="form-control">
                    <i class="fa fa-youtube input-icon"></i>
                </div> 
                
                <div class="form-group">
                    <label>{{__("Twitter")}}</label>
                    <input type="text" value="{{old('twitter',$dataUser->twitter)}}" name="twitter" placeholder="{{__("Twitter")}}" class="form-control">
                    <i class="fa fa-twitter input-icon"></i>
                </div>  



            </div>
            <div class="col-md-12">
                <hr>
                <button class="btn btn-primary" type="submit"><i class="fa fa-save"></i> {{__('Save Changes')}}</button>
            </div>
        </div>
    </form>
    @if(!empty(setting_item('user_enable_permanently_delete')) and !is_admin())
    <hr>
    <div class="row">
        <div class="col-md-12">
            <h4 class="text-danger">
                {{__("Delete account")}}
            </h4>
            <div class="mb-4 mt-2">
                {!! clean(setting_item_with_lang('user_permanently_delete_content','',__('Your account will be permanently deleted. Once you delete your account, there is no going back. Please be certain.'))) !!}
            </div>
            <a data-toggle="modal" data-target="#permanentlyDeleteAccount" class="btn btn-danger" href="">{{__('Delete your account')}}</a>
        </div>

        <!-- Modal -->
        <div class="modal  fade" id="permanentlyDeleteAccount" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content ">
                    <div class="modal-header">
                        <h5 class="modal-title">{{__('Confirm permanently delete account')}}</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="my-3">
                            {!! clean(setting_item_with_lang('user_permanently_delete_content_confirm')) !!}
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">{{__('Close')}}</button>
                        <a href="{{route('user.permanently.delete')}}" class="btn btn-danger">{{__('Confirm')}}</a>
                    </div>

                </div>
            </div>
        </div>
    </div>
    @endif

@endsection

@push('js')
    {!! App\Helpers\MapEngine::scripts() !!}
    <script>
        jQuery(function ($) {
            new BravoMapEngine('map_content', {
                disableScripts: true,
                fitBounds: true,
                center: [{{$dataUser->map_lat ?? setting_item('map_lat_default',51.505 ) }}, {{$dataUser->map_lng ?? setting_item('map_lng_default',-0.09 ) }}],
                zoom:{{$dataUser->map_zoom ?? 18}},
                ready: function (engineMap) {
                    @if($dataUser->map_lat && $dataUser->map_lng)
                    engineMap.addMarker([{{$dataUser->map_lat}}, {{$dataUser->map_lng}}], {
                        icon_options: {}
                    });
                    @endif
                    engineMap.on('click', function (dataLatLng) {
                        engineMap.clearMarkers();
                        engineMap.addMarker(dataLatLng, {
                            icon_options: {}
                        });
                        $("input[name=map_lat]").attr("value", dataLatLng[0]);
                        $("input[name=map_lng]").attr("value", dataLatLng[1]);
                    });
                    engineMap.on('zoom_changed', function (zoom) {
                        $("input[name=map_zoom]").attr("value", zoom);
                    });
                    if(bookingCore.map_provider === "gmap"){
                        engineMap.searchBox($('#customPlaceAddress'),function (dataLatLng) {
                            engineMap.clearMarkers();
                            engineMap.addMarker(dataLatLng, {
                                icon_options: {}
                            });
                            $("input[name=map_lat]").attr("value", dataLatLng[0]);
                            $("input[name=map_lng]").attr("value", dataLatLng[1]);
                        });
                    }
                    engineMap.searchBox($('.bravo_searchbox'),function (dataLatLng) {
                        engineMap.clearMarkers();
                        engineMap.addMarker(dataLatLng, {
                            icon_options: {}
                        });
                        $("input[name=map_lat]").attr("value", dataLatLng[0]);
                        $("input[name=map_lng]").attr("value", dataLatLng[1]);
                    });
                }
            });
        })
    </script>
@endpush
