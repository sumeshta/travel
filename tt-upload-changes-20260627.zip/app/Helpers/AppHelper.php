<?php
use Modules\Core\Models\Settings;
use App\Currency;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;

//include '../../custom/Helpers/CustomHelper.php';

define( 'MINUTE_IN_SECONDS', 60 );
define( 'HOUR_IN_SECONDS', 60 * MINUTE_IN_SECONDS );
define( 'DAY_IN_SECONDS', 24 * HOUR_IN_SECONDS );
define( 'WEEK_IN_SECONDS', 7 * DAY_IN_SECONDS );
define( 'MONTH_IN_SECONDS', 30 * DAY_IN_SECONDS );
define( 'YEAR_IN_SECONDS', 365 * DAY_IN_SECONDS );

function setting_item($item,$default = '',$isArray = false){

    $res = Settings::item($item,$default);

    if($isArray and !is_array($res)){
        $res = (array) json_decode($res,true);
    }

    return $res;

}
function setting_item_array($item,$default = ''){

    return setting_item($item,$default,true);

}

function setting_item_with_lang($item,$locale = '',$default = '',$withOrigin = true){

    if(empty($locale)) $locale = app()->getLocale();

    if($withOrigin == false and $locale == setting_item('site_locale')){
        return $default;
    }

    if( empty(setting_item('site_locale'))
        OR empty(setting_item('site_enable_multi_lang'))
        OR  $locale == setting_item('site_locale')
    ){
        $locale = '';
    }

    return Settings::item($item.($locale ? '_'.$locale : ''),$withOrigin ? setting_item($item,$default) : $default);

}
function setting_item_with_lang_raw($item,$locale = '',$default = ''){

    return setting_item_with_lang($item,$locale,$default,false);
}
function setting_update_item($item,$val){

    $s = Settings::where('name',$item)->first();
    if(empty($s)){
        $s = new Settings();
        $s->name = $item;
    }

    if(is_array($val) or is_object($val)) $val = json_encode($val);
    $s->val = $val;

    $s->save();

    Cache::forget('setting_' . $item);

    return $s;
}

function app_get_locale($locale = false , $before = false , $after = false){
    if(setting_item('site_enable_multi_lang') and app()->getLocale() != setting_item('site_locale')){
        return $locale ? $before.$locale.$after : $before.app()->getLocale().$after;
    }
    return '';
}

function format_money($price){

   return Currency::format((float)$price);

}
function format_money_main($price){

   return Currency::format((float)$price,true);

}

function service_price_currency_code($row = null)
{
    return strtolower((string) ($row->price_currency ?? setting_item('currency_main', 'usd')));
}

/**
 * Return a service price normalized to the site main currency.
 * Prices should be stored in main currency; legacy rows may still hold local amounts.
 */
function service_price_amount_in_main($row, $field = 'price', $currencyContext = null)
{
    $amount = $row->{$field} ?? null;
    if ($amount === '' || $amount === null) {
        return 0.0;
    }

    $amount = (float) $amount;
    if ($amount <= 0) {
        return $amount;
    }

    $main = strtolower((string) setting_item('currency_main', 'usd'));
    $context = $currencyContext ?? $row;
    $currency = strtolower((string) ($context->price_currency ?? ''));
    $legacyCurrency = strtolower((string) setting_item('service_price_input_currency', 'inr'));

    $looksLikeUnconvertedLocal = function (float $value, string $localCurrency) use ($main): bool {
        if ($localCurrency === '' || $localCurrency === $main) {
            return false;
        }

        $rate = Currency::getExchangeRateForCurrency($localCurrency);
        if ($rate <= 0) {
            return false;
        }

        $asLocalIfStoredAsMain = $value / $rate;

        // Large round local amounts (e.g. 54800 INR) stored without USD conversion.
        if ($asLocalIfStoredAsMain > 500000 && $value > 30000) {
            return true;
        }

        // price_currency set to INR but value still stored as INR, not USD.
        if ($value > 10000 && $asLocalIfStoredAsMain > 100000) {
            return true;
        }

        return false;
    };

    // price_currency set to a non-main currency — value should already be in main.
    if ($currency !== '' && $currency !== $main) {
        if ($looksLikeUnconvertedLocal($amount, $currency)) {
            return Currency::convertFromCurrencyToMain($amount, $currency);
        }

        return $amount;
    }

    // price_currency empty or main — legacy local amounts may have been saved without conversion.
    if ($legacyCurrency && $legacyCurrency !== $main) {
        if ($looksLikeUnconvertedLocal($amount, $legacyCurrency)) {
            return Currency::convertFromCurrencyToMain($amount, $legacyCurrency);
        }
    }

    return $amount;
}

function service_effective_price_in_main($row, $currencyContext = null)
{
    $price = service_price_amount_in_main($row, 'price', $currencyContext);
    $salePrice = service_price_amount_in_main($row, 'sale_price', $currencyContext);

    if ($salePrice > 0 && $price > 0 && $salePrice < $price) {
        return $salePrice;
    }

    return $price;
}

function service_amount_in_main($row, $amount, $currencyContext = null)
{
    $wrapper = (object) ['price' => $amount];

    return service_price_amount_in_main($wrapper, 'price', $currencyContext ?? $row);
}

function format_service_money($row, $amount, $currencyContext = null)
{
    return format_money(service_amount_in_main($row, $amount, $currencyContext));
}

function service_price_for_admin($row, $field = 'price')
{
    $currency = service_price_currency_code($row);
    $stored = $row->$field ?? null;

    if ($stored === '' || $stored === null) {
        return ['amount' => '', 'currency' => $currency];
    }

    $mainAmount = service_price_amount_in_main($row, $field);

    $storedCurrency = strtolower((string) ($row->price_currency ?? ''));
    $main = strtolower((string) setting_item('currency_main', 'usd'));
    $legacyCurrency = strtolower((string) setting_item('service_price_input_currency', 'inr'));

    if (abs($mainAmount - (float) $stored) > 0.01) {
        if ($storedCurrency !== '' && $storedCurrency !== $main) {
            $currency = $storedCurrency;
        } elseif ($legacyCurrency) {
            $currency = $legacyCurrency;
        }
    }

    return [
        'amount' => Currency::convertFromMainToCurrency($mainAmount, $currency),
        'currency' => $currency,
    ];
}

function service_price_currency_options()
{
    return Currency::getAdminCurrencyOptions();
}

function apply_service_price_currency_to_request(\Illuminate\Http\Request $request, array $fields = ['price', 'sale_price'])
{
    $currency = strtolower((string) $request->input('price_currency', setting_item('currency_main', 'usd')));
    $request->merge(['price_currency' => $currency]);

    foreach ($fields as $field) {
        if (!$request->exists($field)) {
            continue;
        }

        $value = $request->input($field);
        if ($value === '' || $value === null) {
            continue;
        }

        $request->merge([
            $field => Currency::convertFromCurrencyToMain((float) $value, $currency),
        ]);
    }
}

function currency_symbol(){

    $currency_main = get_current_currency('currency_main');

    $currency = Currency::getCurrency($currency_main);

    return $currency['symbol'] ?? '';
}

function generate_menu($location = '',$options = [])
{
    $options['walker'] = $options['walker'] ?? '\\Modules\\Core\\Walkers\\MenuWalker';

    $setting = json_decode(setting_item('menu_locations'),true);

    if(!empty($setting))
    {
        foreach($setting as $l=>$menuId){
            if($l == $location and $menuId){
                $menu = (new \Modules\Core\Models\Menu())->findById($menuId);
                $translation = $menu->translate();

                $walker = new $options['walker']($translation);

                if(!empty($translation)){
                    $walker->generate($options);
                }
            }
        }
    }
}

function set_active_menu($item){
    \Modules\Core\Walkers\MenuWalker::setCurrentMenuItem($item);
}

 function get_exceprt($string,$length=200,$more = "[...]"){
        $string=strip_tags($string);
        if(str_word_count($string)>0) {
            $arr=explode(' ',$string);
            $excerpt='';
            if(count($arr)>0) {
                $count=0;
                if($arr) foreach($arr as $str) {
                    $count+=strlen($str);
                    if($count>$length) {
                        $excerpt.= $more;
                        break;
                    }
                    $excerpt.=' '.$str;
                }
                }return $excerpt;
            }
}

function getDatefomat($value) {
    return \Carbon\Carbon::parse($value)->format('j F, Y');

}

function get_file_url($file_id,$size="thumb",$resize = true){
    if(empty($file_id)) return null;
    return \Modules\Media\Helpers\FileHelper::url($file_id,$size,$resize);
}

function get_image_tag($image_id,$size = 'thumb',$options = []){
    $options = array_merge([
       'lazy'=>true
    ],$options);
    $url = get_file_url($image_id,$size);

    if($url){
        $alt = $options['alt'] ?? '';
        $attr = '';
        $class= $options['class'] ?? '';
        if(!empty($options['lazy'])){
            $class.=' lazy';
            $attr.=" data-src=".e($url)." ";
        }else{
            $attr.=" src='".e($url)."' ";
        }
        return sprintf("<img class='%s' %s alt='%s'>",e($class),$attr,e($alt));
    }
}
function get_date_format(){
    return setting_item('date_format','m/d/Y');
}
function get_moment_date_format(){
    return php_to_moment_format(get_date_format());
}
function php_to_moment_format($format){

    $replacements = [
        'd' => 'DD',
        'D' => 'ddd',
        'j' => 'D',
        'l' => 'dddd',
        'N' => 'E',
        'S' => 'o',
        'w' => 'e',
        'z' => 'DDD',
        'W' => 'W',
        'F' => 'MMMM',
        'm' => 'MM',
        'M' => 'MMM',
        'n' => 'M',
        't' => '', // no equivalent
        'L' => '', // no equivalent
        'o' => 'YYYY',
        'Y' => 'YYYY',
        'y' => 'YY',
        'a' => 'a',
        'A' => 'A',
        'B' => '', // no equivalent
        'g' => 'h',
        'G' => 'H',
        'h' => 'hh',
        'H' => 'HH',
        'i' => 'mm',
        's' => 'ss',
        'u' => 'SSS',
        'e' => 'zz', // deprecated since version 1.6.0 of moment.js
        'I' => '', // no equivalent
        'O' => '', // no equivalent
        'P' => '', // no equivalent
        'T' => '', // no equivalent
        'Z' => '', // no equivalent
        'c' => '', // no equivalent
        'r' => '', // no equivalent
        'U' => 'X',
    ];
    $momentFormat = strtr($format, $replacements);
    return $momentFormat;
}

function display_date($time){

    if($time){
        if(is_string($time)){
            $time = strtotime($time);
        }

        if(is_object($time)){
            return $time->format(get_date_format());
        }
    }else{
       $time=strtotime(today());
    }

    return date(get_date_format(),$time);
}

function display_datetime($time){

    if(is_string($time)){
        $time = strtotime($time);
    }

    if(is_object($time)){
        return $time->format(get_date_format().' H:i');
    }

    return date(get_date_format().' H:i',$time);
}

function human_time_diff($from,$to = false){

    if(is_string($from)) $from = strtotime($from);
    if(is_string($to)) $to = strtotime($to);

    if ( empty( $to ) ) {
        $to = time();
    }

    $diff = (int) abs( $to - $from );

    if ( $diff < HOUR_IN_SECONDS ) {
        $mins = round( $diff / MINUTE_IN_SECONDS );
        if ( $mins <= 1 ) {
            $mins = 1;
        }
        /* translators: Time difference between two dates, in minutes (min=minute). %s: Number of minutes */
        if($mins){
            $since =__(':num mins',['num'=>$mins]);
        }else{
            $since =__(':num min',['num'=>$mins]);
        }

    } elseif ( $diff < DAY_IN_SECONDS && $diff >= HOUR_IN_SECONDS ) {
        $hours = round( $diff / HOUR_IN_SECONDS );
        if ( $hours <= 1 ) {
            $hours = 1;
        }
        /* translators: Time difference between two dates, in hours. %s: Number of hours */
        if($hours){
            $since =__(':num hours',['num'=>$hours]);
        }else{
            $since =__(':num hour',['num'=>$hours]);
        }

    } elseif ( $diff < WEEK_IN_SECONDS && $diff >= DAY_IN_SECONDS ) {
        $days = round( $diff / DAY_IN_SECONDS );
        if ( $days <= 1 ) {
            $days = 1;
        }
        /* translators: Time difference between two dates, in days. %s: Number of days */
        if($days){
            $since =__(':num days',['num'=>$days]);
        }else{
            $since =__(':num day',['num'=>$days]);
        }

    } elseif ( $diff < MONTH_IN_SECONDS && $diff >= WEEK_IN_SECONDS ) {
        $weeks = round( $diff / WEEK_IN_SECONDS );
        if ( $weeks <= 1 ) {
            $weeks = 1;
        }
        /* translators: Time difference between two dates, in weeks. %s: Number of weeks */
        if($weeks){
            $since =__(':num weeks',['num'=>$weeks]);
        }else{
            $since =__(':num week',['num'=>$weeks]);
        }

    } elseif ( $diff < YEAR_IN_SECONDS && $diff >= MONTH_IN_SECONDS ) {
        $months = round( $diff / MONTH_IN_SECONDS );
        if ( $months <= 1 ) {
            $months = 1;
        }
        /* translators: Time difference between two dates, in months. %s: Number of months */

        if($months){
            $since =__(':num months',['num'=>$months]);
        }else{
            $since =__(':num month',['num'=>$months]);
        }

    } elseif ( $diff >= YEAR_IN_SECONDS ) {
        $years = round( $diff / YEAR_IN_SECONDS );
        if ( $years <= 1 ) {
            $years = 1;
        }
        /* translators: Time difference between two dates, in years. %s: Number of years */
        if($years){
            $since =__(':num years',['num'=>$years]);
        }else{
            $since =__(':num year',['num'=>$years]);
        }
    }

    return $since;
}

function human_time_diff_short($from,$to = false){
    if(!$to) $to = time();
    $today = strtotime(date('Y-m-d 00:00:00',$to));

    $diff = $from - $to;

    if($from > $today){
        return date('h:i A',$from);
    }

    if($diff < 5* DAY_IN_SECONDS){
        return date('D',$from);
    }

    return date('M d',$from);
}

function _n($l,$m,$count){
    if($count){
        return $m;
    }
    return $l;
}
function get_country_lists(){
    $countries = array
    (
        'AF' => 'Afghanistan',
        'AX' => 'Aland Islands',
        'AL' => 'Albania',
        'DZ' => 'Algeria',
        'AS' => 'American Samoa',
        'AD' => 'Andorra',
        'AO' => 'Angola',
        'AI' => 'Anguilla',
        'AQ' => 'Antarctica',
        'AG' => 'Antigua And Barbuda',
        'AR' => 'Argentina',
        'AM' => 'Armenia',
        'AW' => 'Aruba',
        'AU' => 'Australia',
        'AT' => 'Austria',
        'AZ' => 'Azerbaijan',
        'BS' => 'Bahamas',
        'BH' => 'Bahrain',
        'BD' => 'Bangladesh',
        'BB' => 'Barbados',
        'BY' => 'Belarus',
        'BE' => 'Belgium',
        'BZ' => 'Belize',
        'BJ' => 'Benin',
        'BM' => 'Bermuda',
        'BT' => 'Bhutan',
        'BO' => 'Bolivia',
        'BA' => 'Bosnia And Herzegovina',
        'BW' => 'Botswana',
        'BV' => 'Bouvet Island',
        'BR' => 'Brazil',
        'IO' => 'British Indian Ocean Territory',
        'BN' => 'Brunei Darussalam',
        'BG' => 'Bulgaria',
        'BF' => 'Burkina Faso',
        'BI' => 'Burundi',
        'KH' => 'Cambodia',
        'CM' => 'Cameroon',
        'CA' => 'Canada',
        'CV' => 'Cape Verde',
        'KY' => 'Cayman Islands',
        'CF' => 'Central African Republic',
        'TD' => 'Chad',
        'CL' => 'Chile',
        'CN' => 'China',
        'CX' => 'Christmas Island',
        'CC' => 'Cocos (Keeling) Islands',
        'CO' => 'Colombia',
        'KM' => 'Comoros',
        'CG' => 'Congo',
        'CD' => 'Congo, Democratic Republic',
        'CK' => 'Cook Islands',
        'CR' => 'Costa Rica',
        'CI' => 'Cote D\'Ivoire',
        'HR' => 'Croatia',
        'CU' => 'Cuba',
        'CY' => 'Cyprus',
        'CZ' => 'Czech Republic',
        'DK' => 'Denmark',
        'DJ' => 'Djibouti',
        'DM' => 'Dominica',
        'DO' => 'Dominican Republic',
        'EC' => 'Ecuador',
        'EG' => 'Egypt',
        'SV' => 'El Salvador',
        'GQ' => 'Equatorial Guinea',
        'ER' => 'Eritrea',
        'EE' => 'Estonia',
        'ET' => 'Ethiopia',
        'FK' => 'Falkland Islands (Malvinas)',
        'FO' => 'Faroe Islands',
        'FJ' => 'Fiji',
        'FI' => 'Finland',
        'FR' => 'France',
        'GF' => 'French Guiana',
        'PF' => 'French Polynesia',
        'TF' => 'French Southern Territories',
        'GA' => 'Gabon',
        'GM' => 'Gambia',
        'GE' => 'Georgia',
        'DE' => 'Germany',
        'GH' => 'Ghana',
        'GI' => 'Gibraltar',
        'GR' => 'Greece',
        'GL' => 'Greenland',
        'GD' => 'Grenada',
        'GP' => 'Guadeloupe',
        'GU' => 'Guam',
        'GT' => 'Guatemala',
        'GG' => 'Guernsey',
        'GN' => 'Guinea',
        'GW' => 'Guinea-Bissau',
        'GY' => 'Guyana',
        'HT' => 'Haiti',
        'HM' => 'Heard Island & Mcdonald Islands',
        'VA' => 'Holy See (Vatican City State)',
        'HN' => 'Honduras',
        'HK' => 'Hong Kong',
        'HU' => 'Hungary',
        'IS' => 'Iceland',
        'IN' => 'India',
        'ID' => 'Indonesia',
        'IR' => 'Iran, Islamic Republic Of',
        'IQ' => 'Iraq',
        'IE' => 'Ireland',
        'IM' => 'Isle Of Man',
        'IL' => 'Israel',
        'IT' => 'Italy',
        'JM' => 'Jamaica',
        'JP' => 'Japan',
        'JE' => 'Jersey',
        'JO' => 'Jordan',
        'KZ' => 'Kazakhstan',
        'KE' => 'Kenya',
        'KI' => 'Kiribati',
        'KR' => 'Korea',
        'KW' => 'Kuwait',
        'KG' => 'Kyrgyzstan',
        'LA' => 'Lao People\'s Democratic Republic',
        'LV' => 'Latvia',
        'LB' => 'Lebanon',
        'LS' => 'Lesotho',
        'LR' => 'Liberia',
        'LY' => 'Libyan Arab Jamahiriya',
        'LI' => 'Liechtenstein',
        'LT' => 'Lithuania',
        'LU' => 'Luxembourg',
        'MO' => 'Macao',
        'MK' => 'Macedonia',
        'MG' => 'Madagascar',
        'MW' => 'Malawi',
        'MY' => 'Malaysia',
        'MV' => 'Maldives',
        'ML' => 'Mali',
        'MT' => 'Malta',
        'MH' => 'Marshall Islands',
        'MQ' => 'Martinique',
        'MR' => 'Mauritania',
        'MU' => 'Mauritius',
        'YT' => 'Mayotte',
        'MX' => 'Mexico',
        'FM' => 'Micronesia, Federated States Of',
        'MD' => 'Moldova',
        'MC' => 'Monaco',
        'MN' => 'Mongolia',
        'ME' => 'Montenegro',
        'MS' => 'Montserrat',
        'MA' => 'Morocco',
        'MZ' => 'Mozambique',
        'MM' => 'Myanmar',
        'NA' => 'Namibia',
        'NR' => 'Nauru',
        'NP' => 'Nepal',
        'NL' => 'Netherlands',
        'AN' => 'Netherlands Antilles',
        'NC' => 'New Caledonia',
        'NZ' => 'New Zealand',
        'NI' => 'Nicaragua',
        'NE' => 'Niger',
        'NG' => 'Nigeria',
        'NU' => 'Niue',
        'NF' => 'Norfolk Island',
        'MP' => 'Northern Mariana Islands',
        'NO' => 'Norway',
        'OM' => 'Oman',
        'PK' => 'Pakistan',
        'PW' => 'Palau',
        'PS' => 'Palestinian Territory, Occupied',
        'PA' => 'Panama',
        'PG' => 'Papua New Guinea',
        'PY' => 'Paraguay',
        'PE' => 'Peru',
        'PH' => 'Philippines',
        'PN' => 'Pitcairn',
        'PL' => 'Poland',
        'PT' => 'Portugal',
        'PR' => 'Puerto Rico',
        'QA' => 'Qatar',
        'RE' => 'Reunion',
        'RO' => 'Romania',
        'RU' => 'Russian Federation',
        'RW' => 'Rwanda',
        'BL' => 'Saint Barthelemy',
        'SH' => 'Saint Helena',
        'KN' => 'Saint Kitts And Nevis',
        'LC' => 'Saint Lucia',
        'MF' => 'Saint Martin',
        'PM' => 'Saint Pierre And Miquelon',
        'VC' => 'Saint Vincent And Grenadines',
        'WS' => 'Samoa',
        'SM' => 'San Marino',
        'ST' => 'Sao Tome And Principe',
        'SA' => 'Saudi Arabia',
        'SN' => 'Senegal',
        'RS' => 'Serbia',
        'SC' => 'Seychelles',
        'SL' => 'Sierra Leone',
        'SG' => 'Singapore',
        'SK' => 'Slovakia',
        'SI' => 'Slovenia',
        'SB' => 'Solomon Islands',
        'SO' => 'Somalia',
        'ZA' => 'South Africa',
        'GS' => 'South Georgia And Sandwich Isl.',
        'ES' => 'Spain',
        'LK' => 'Sri Lanka',
        'SD' => 'Sudan',
        'SR' => 'Suriname',
        'SJ' => 'Svalbard And Jan Mayen',
        'SZ' => 'Swaziland',
        'SE' => 'Sweden',
        'CH' => 'Switzerland',
        'SY' => 'Syrian Arab Republic',
        'TW' => 'Taiwan',
        'TJ' => 'Tajikistan',
        'TZ' => 'Tanzania',
        'TH' => 'Thailand',
        'TL' => 'Timor-Leste',
        'TG' => 'Togo',
        'TK' => 'Tokelau',
        'TO' => 'Tonga',
        'TT' => 'Trinidad And Tobago',
        'TN' => 'Tunisia',
        'TR' => 'Turkey',
        'TM' => 'Turkmenistan',
        'TC' => 'Turks And Caicos Islands',
        'TV' => 'Tuvalu',
        'UG' => 'Uganda',
        'UA' => 'Ukraine',
        'AE' => 'United Arab Emirates',
        'GB' => 'United Kingdom',
        'US' => 'United States',
        'UM' => 'United States Outlying Islands',
        'UY' => 'Uruguay',
        'UZ' => 'Uzbekistan',
        'VU' => 'Vanuatu',
        'VE' => 'Venezuela',
        'VN' => 'Viet Nam',
        'VG' => 'Virgin Islands, British',
        'VI' => 'Virgin Islands, U.S.',
        'WF' => 'Wallis And Futuna',
        'EH' => 'Western Sahara',
        'YE' => 'Yemen',
        'ZM' => 'Zambia',
        'ZW' => 'Zimbabwe',
    );
    return $countries;
}

function get_country_name($name){
    $all = get_country_lists();

    return $all[$name] ?? $name;
}

function get_request_route_segments()
{
    $segments = request()->segments();

    if (setting_item('site_enable_multi_lang') && class_exists(\Modules\Language\Models\Language::class)) {
        $localeCodes = \Modules\Language\Models\Language::getActive()->pluck('locale')->all();
        if (!empty($segments[0]) && in_array($segments[0], $localeCodes, true)) {
            array_shift($segments);
        }
    }

    return [
        $segments[0] ?? null,
        $segments[1] ?? null,
    ];
}

function get_service_detail_route_prefixes()
{
    static $prefixes = null;

    if ($prefixes !== null) {
        return $prefixes;
    }

    $prefixes = array_values(array_filter([
        config('tour.tour_route_prefix'),
        config('hotel.hotel_route_prefix'),
        config('car.car_route_prefix'),
        config('space.space_route_prefix'),
        config('event.event_route_prefix'),
        config('boat.boat_route_prefix'),
        config('news.news_route_prefix'),
        config('flight.flight_route_prefix'),
    ]));

    return $prefixes;
}

function is_service_detail_page()
{
    [$prefix, $slug] = get_request_route_segments();

    return !empty($prefix) && !empty($slug) && in_array($prefix, get_service_detail_route_prefixes(), true);
}

function get_site_share_image()
{
    $logoId = setting_item('logo_id');
    if (!empty($logoId)) {
        $url = get_file_url($logoId, 'full');
        if (!empty($url)) {
            return $url;
        }
    }

    $favicon = setting_item('site_favicon');
    if (!empty($favicon)) {
        $url = get_file_url($favicon, 'full');
        if (!empty($url)) {
            return $url;
        }
    }

    return url('images/favicon.png');
}

function get_service_share_image($row = null)
{
    if (empty($row)) {
        return get_site_share_image();
    }

    if (method_exists($row, 'getSeoMeta')) {
        $meta = $row->getSeoMeta();
        if (!empty($meta['seo_share']['facebook']['image'])) {
            $url = get_file_url($meta['seo_share']['facebook']['image'], 'full');
            if (!empty($url)) {
                return $url;
            }
        }
    }

    if (method_exists($row, 'getGallery')) {
        $gallery = $row->getGallery(true);
        if (!empty($gallery[0]['large'])) {
            return $gallery[0]['large'];
        }
        if (!empty($gallery[0]['thumb'])) {
            return $gallery[0]['thumb'];
        }
    }

    if (!empty($row->image_id)) {
        $url = get_file_url($row->image_id, 'full');
        if (!empty($url)) {
            return $url;
        }
    }

    return get_site_share_image();
}

function get_absolute_url($url)
{
    if (empty($url)) {
        return $url;
    }

    if (preg_match('/^https?:\/\//i', $url)) {
        return $url;
    }

    return url($url);
}

function get_country_iso_by_name($name)
{
    static $lookup = null;

    $name = trim((string) $name);
    if ($name === '') {
        return null;
    }

    if ($lookup === null) {
        $lookup = [];
        foreach (get_country_lists() as $code => $countryName) {
            $lookup[strtolower($countryName)] = strtolower($code);
        }
        $aliases = [
            'usa' => 'us',
            'u.s.a.' => 'us',
            'u.s.' => 'us',
            'uk' => 'gb',
            'england' => 'gb',
            'uae' => 'ae',
            'united arab emirates' => 'ae',
            'czech republic' => 'cz',
            'czechia' => 'cz',
            'south korea' => 'kr',
            'north korea' => 'kp',
            'russia' => 'ru',
            'viet nam' => 'vn',
        ];
        $lookup = array_merge($lookup, $aliases);
    }

    $key = strtolower($name);
    if (isset($lookup[$key])) {
        return $lookup[$key];
    }

    if (strlen($key) === 2 && isset(get_country_lists()[strtoupper($key)])) {
        return $key;
    }

    return null;
}

function get_location_country_info($location)
{
    if (empty($location)) {
        return null;
    }

    $names = [];
    $current = $location;
    $guard = 0;

    while ($current && $guard < 10) {
        $translation = method_exists($current, 'translate') ? $current->translate() : null;
        $name = trim($translation->name ?? $current->name ?? '');
        if ($name !== '') {
            $names[] = $name;
        }

        if (empty($current->parent_id)) {
            break;
        }

        if (!$current->relationLoaded('parent')) {
            $current->load('parent');
        }
        $current = $current->parent;
        $guard++;
    }

    foreach ($names as $name) {
        if (strpos($name, ',') !== false) {
            $parts = array_map('trim', explode(',', $name));
            foreach (array_reverse($parts) as $part) {
                $code = get_country_iso_by_name($part);
                if ($code) {
                    return [
                        'name' => get_country_name(strtoupper($code)),
                        'code' => $code,
                    ];
                }
            }
        }

        $code = get_country_iso_by_name($name);
        if ($code) {
            return [
                'name' => get_country_name(strtoupper($code)),
                'code' => $code,
            ];
        }

        $regionCode = config('location.region_country_map.' . strtolower($name));
        if ($regionCode) {
            $regionCode = strtolower($regionCode);
            return [
                'name' => get_country_name(strtoupper($regionCode)),
                'code' => $regionCode,
            ];
        }
    }

    return null;
}

function get_location_display_parts($location)
{
    if (empty($location)) {
        return ['city' => '', 'country' => null];
    }

    $translation = method_exists($location, 'translate') ? $location->translate() : null;
    $fullName = trim($translation->name ?? $location->name ?? '');
    $country = get_location_country_info($location);
    $city = $fullName;

    if ($fullName !== '' && strpos($fullName, ',') !== false) {
        $parts = array_map('trim', explode(',', $fullName));
        $city = $parts[0];
    } elseif ($country && strcasecmp($fullName, $country['name']) === 0) {
        $city = '';
    }

    return [
        'city' => $city,
        'country' => $country,
    ];
}

function get_page_url($page_id)
{
    $page = \Modules\Page\Models\Page::find($page_id);

    if($page){
        return $page->getDetailUrl();
    }
    return false;
}

function get_payment_gateway_obj($payment_gateway){

    $gateways = get_payment_gateways();

    if(empty($gateways[$payment_gateway]) or !class_exists($gateways[$payment_gateway]))
    {
        return false;
    }

    $gatewayObj = new $gateways[$payment_gateway]($payment_gateway);

    return $gatewayObj;

}

function recaptcha_field($action){
    return \App\Helpers\ReCaptchaEngine::captcha($action);
}

function add_query_arg($args,$uri = false) {

    if(empty($uri)) $uri = request()->url();

    $query = request()->query();

    if(!empty($args)){
        foreach ($args as $k=>$arg){
            $query[$k] = $arg;
        }
    }

    return $uri.'?'.http_build_query($query);
}

function is_default_lang($lang = '')
{
    if(!$lang) $lang = request()->query('lang');
    if(!$lang) $lang = request()->route('lang');

    if(empty($lang) or $lang == setting_item('site_locale')) return true;

    return false;
}

function get_lang_switcher_url($locale = false){

    $request =  request();
    $data = $request->query();
    $data['set_lang'] = $locale;

    $url = url()->current();

    $url.='?'.http_build_query($data);

    return url($url);
}
function get_currency_switcher_url($code = false){

    $request =  request();
    $data = $request->query();
    $data['set_currency'] = $code ? strtolower((string) $code) : $code;

    $url = url()->current();

    $url.='?'.http_build_query($data);

    return url($url);
}

/**
 * Build Google Maps search URL for a free-text address query.
 */
function google_maps_search_url(string $query): ?string
{
    $query = trim(preg_replace('/\s*,\s*/', ', ', preg_replace('/,+/', ',', $query)), ', ');
    if ($query === '') {
        return null;
    }

    return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($query);
}

/**
 * Resolve display name for Google Maps place link (prefer listing title).
 */
function vendor_profile_place_name($user): ?string
{
    if (class_exists(\Modules\Hotel\Models\Hotel::class) && !empty($user->id)) {
        $hotel = \Modules\Hotel\Models\Hotel::query()
            ->where('author_id', $user->id)
            ->where('status', 'publish')
            ->orderByDesc('id')
            ->first(['title']);
        if ($hotel && filled($hotel->title)) {
            return trim((string) $hotel->title);
        }
    }

    $name = trim((string) ($user->business_name ?: (method_exists($user, 'getDisplayName') ? $user->getDisplayName() : '')));

    return $name !== '' ? $name : null;
}

/**
 * Use explicit Google Maps URL when set, otherwise build from coords + place name.
 */
function google_maps_resolve_url($lat, $lng, $zoom, ?string $placeName = null, ?string $overrideUrl = null): ?string
{
    $overrideUrl = trim((string) $overrideUrl);
    if ($overrideUrl !== '' && preg_match('#^https?://#i', $overrideUrl)) {
        return $overrideUrl;
    }

    if (!is_numeric($lat) || !is_numeric($lng)) {
        return null;
    }

    return google_maps_coords_url($lat, $lng, $zoom, $placeName);
}

/**
 * Build Google Maps URL for latitude/longitude coordinates (pin + focused view).
 */
function google_maps_coords_url($lat, $lng, $zoom = 18, ?string $placeName = null): ?string
{
    if (!is_numeric($lat) || !is_numeric($lng)) {
        return null;
    }

    $lat = (float) $lat;
    $lng = (float) $lng;

    if ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
        return null;
    }

    if (abs($lat) < 0.000001 && abs($lng) < 0.000001) {
        return null;
    }

    $zoom = max(14, min(21, (int) ($zoom ?: 18)));
    $latStr = rtrim(rtrim(sprintf('%.7f', $lat), '0'), '.');
    $lngStr = rtrim(rtrim(sprintf('%.7f', $lng), '0'), '.');

    $placeName = trim((string) $placeName);
    if ($placeName !== '') {
        return sprintf(
            'https://www.google.com/maps/place/%s/@%s,%s,%dz',
            rawurlencode($placeName),
            $latStr,
            $lngStr,
            $zoom
        );
    }

    // Never use /place//@ — coords-only fallback
    return sprintf(
        'https://www.google.com/maps/search/?api=1&query=%s&zoom=%d',
        rawurlencode($latStr . ',' . $lngStr),
        $zoom
    );
}

/**
 * Google Maps URL for a bookable listing (hotel, tour, etc.) with map coordinates.
 */
function bookable_google_maps_url($row, ?string $title = null): ?string
{
    $overrideUrl = $row->map_google_url ?? null;
    if ($overrideUrl) {
        return $overrideUrl;
    }

    if (empty($row->map_lat) || empty($row->map_lng)) {
        $address = $row->address ?? null;
        if (is_string($address) && trim($address) !== '') {
            return google_maps_search_url($address);
        }

        return null;
    }

    $title = $title
        ?? (method_exists($row, 'translate') ? ($row->translate()->title ?? null) : null)
        ?? ($row->title ?? null);

    return google_maps_resolve_url(
        $row->map_lat,
        $row->map_lng,
        $row->map_zoom ?? 18,
        $title,
        $overrideUrl
    );
}

/**
 * Resolve map coordinates from a user/vendor record.
 *
 * @return array{lat: float, lng: float, zoom: int}|null
 */
function vendor_profile_map_coordinates($user): ?array
{
    $lat = $user->map_lat ?? null;
    $lng = $user->map_lng ?? null;
    $zoom = $user->map_zoom ?? null;

    if (method_exists($user, 'getMeta')) {
        if (!is_numeric($lat)) {
            $lat = $user->getMeta('map_lat') ?: $user->getMeta('latitude');
        }
        if (!is_numeric($lng)) {
            $lng = $user->getMeta('map_lng') ?: $user->getMeta('longitude');
        }
        if (!is_numeric($zoom)) {
            $zoom = $user->getMeta('map_zoom');
        }
    }

    if (!is_numeric($lat) || !is_numeric($lng)) {
        return null;
    }

    return [
        'lat' => (float) $lat,
        'lng' => (float) $lng,
        'zoom' => max(14, min(21, (int) ($zoom ?: 18))),
    ];
}

/**
 * Vendor profile address parts for display (sidebar lines).
 */
function vendor_profile_address_lines($user): array
{
    return array_values(array_filter([
        $user->address ?? null,
        $user->address2 ?? null,
        $user->city ?? null,
        $user->state ?? null,
        $user->zip_code ?? null,
        !empty($user->country) ? get_country_name($user->country) : null,
    ], fn ($line) => filled(trim((string) $line, " \t\n\r\0\x0B,"))));
}

/**
 * Google Maps URL for a vendor/user profile (coordinates preferred).
 */
function vendor_profile_google_maps_url($user): ?string
{
    $overrideUrl = $user->map_google_url ?? null;
    if (method_exists($user, 'getMeta') && empty($overrideUrl)) {
        $overrideUrl = $user->getMeta('map_google_url') ?: null;
    }

    $coords = vendor_profile_map_coordinates($user);
    if ($coords) {
        $placeName = vendor_profile_place_name($user);

        // Inherit exact Maps URL from vendor's published hotel when set
        if (empty($overrideUrl) && class_exists(\Modules\Hotel\Models\Hotel::class)) {
            $hotel = \Modules\Hotel\Models\Hotel::query()
                ->where('author_id', $user->id)
                ->where('status', 'publish')
                ->whereNotNull('map_google_url')
                ->orderByDesc('id')
                ->value('map_google_url');
            $overrideUrl = $hotel ?: null;
        }

        return google_maps_resolve_url(
            $coords['lat'],
            $coords['lng'],
            $coords['zoom'],
            $placeName,
            $overrideUrl
        );
    }

    if ($overrideUrl) {
        return $overrideUrl;
    }

    $lines = vendor_profile_address_lines($user);
    if (empty($lines)) {
        return null;
    }

    $parts = array_map(
        fn ($line) => trim((string) $line, " \t\n\r\0\x0B,"),
        $lines
    );

    return google_maps_search_url(implode(', ', $parts));
}

/**
 * Add social-link classes to footer widget anchors (Facebook, Instagram, etc.).
 */
function enrich_footer_social_links($html)
{
    if (!is_string($html) || $html === '') {
        return $html;
    }

    $iconClassMap = [
        'facebook' => 'social-facebook',
        'youtube-play' => 'social-youtube',
        'youtube' => 'social-youtube',
        'instagram' => 'social-instagram',
        'twitter' => 'social-twitter',
        'linkedin' => 'social-linkedin',
    ];

    return preg_replace_callback(
        '/<a\b([^>]*)>(.*?)<\/a>/is',
        function ($matches) use ($iconClassMap) {
            $attrs = $matches[1];
            $inner = $matches[2];

            if (stripos($attrs, 'social-link') !== false) {
                return $matches[0];
            }

            $socialClass = null;
            foreach ($iconClassMap as $iconFragment => $class) {
                if (preg_match('/\b(?:icofont|fa)-' . preg_quote($iconFragment, '/') . '\b/i', $inner)) {
                    $socialClass = $class;
                    break;
                }
            }

            if (!$socialClass) {
                return $matches[0];
            }

            if (preg_match('/\bclass=("|\')(.*?)\1/i', $attrs, $classMatch)) {
                $quote = $classMatch[1];
                $existing = $classMatch[2];
                $newClass = trim('social-link ' . $socialClass . ' ' . $existing);
                $attrs = preg_replace('/\bclass=("|\').*?\1/i', 'class=' . $quote . $newClass . $quote, $attrs, 1);
            } else {
                $attrs .= ' class="social-link ' . $socialClass . '"';
            }

            if (stripos($attrs, 'target=') === false) {
                $attrs .= ' target="_blank" rel="noopener noreferrer"';
            }

            return '<a' . $attrs . '>' . $inner . '</a>';
        },
        $html
    );
}


function translate_or_origin($key,$settings = [],$locale = '')
{
    if(empty($locale)) $locale = request()->query('lang');

    if($locale and $locale == setting_item('site_locale')) $locale = false;

    if(empty($locale)) return $settings[$key] ?? '';
    else{
        return $settings[$key.'_'.$locale] ?? '';
    }
}

function get_bookable_services(){

    $all = [];

    // Modules
    $custom_modules = \Modules\ServiceProvider::getActivatedModules();
    if(!empty($custom_modules)){
        foreach($custom_modules as $moduleData){
            $moduleClass = $moduleData['class'];
            if(class_exists($moduleClass))
            {
                $services = call_user_func([$moduleClass,'getBookableServices']);
                $all = array_merge($all,$services);
            }

        }
    }


    // Plugin Menu
    $plugins_modules = \Plugins\ServiceProvider::getModules();
    if(!empty($plugins_modules)){
        foreach($plugins_modules as $module){
            $moduleClass = "\\Plugins\\".ucfirst($module)."\\ModuleProvider";
            if(class_exists($moduleClass))
            {
                $services = call_user_func([$moduleClass,'getBookableServices']);
                $all = array_merge($all,$services);
            }
        }
    }
    foreach ($all as $id=>$class){
        $all[$id] = get_class(app()->make($class));
    }
    return $all;
}
function get_payable_services(){
    $all = get_bookable_services();

    // Modules
    $custom_modules = \Modules\ServiceProvider::getActivatedModules();
    if(!empty($custom_modules)){
        foreach($custom_modules as $moduleData){
            $moduleClass = $moduleData['class'];
            if(class_exists($moduleClass))
            {
                $services = call_user_func([$moduleClass,'getPayableServices']);
                $all = array_merge($all,$services);
            }

        }
    }

    foreach ($all as $id=>$class){
        $all[$id] = get_class(app()->make($class));
    }

    return $all;
}
function get_reviewable_services(){

    $all = get_bookable_services();
    // Modules
    $custom_modules = \Modules\ServiceProvider::getActivatedModules();
    if(!empty($custom_modules)){
        foreach($custom_modules as $moduleData){
            $moduleClass = $moduleData['class'];
            if(class_exists($moduleClass))
            {
                $services = call_user_func([$moduleClass,'getReviewableServices']);
                $all = array_merge($all,$services);
            }

        }
    }

    foreach ($all as $id=>$class){
        $all[$id] = get_class(app()->make($class));
    }

    return $all;
}
function get_bookable_service_by_id($id){

    $all = get_bookable_services();

    return $all[$id] ?? null;
}

function file_get_contents_curl($url,$isPost = false,$data = []) {

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);

    if($isPost){
        curl_setopt($ch, CURLOPT_POST, count($data));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }

    $data = curl_exec($ch);
    curl_close($ch);

    return $data;
}

function size_unit_format($number=''){
    switch (setting_item('size_unit')){
        case "m2":
            return $number." m<sup>2</sup>";
            break;
        default:
            return $number." ".__('sqft');
            break;
    }
}

function get_payment_gateways(){
    $gateways = config('payment.gateways');
    // Modules
    $custom_modules = \Modules\ServiceProvider::getModules();
    if(!empty($custom_modules)){
        foreach($custom_modules as $module){
            $moduleClass = "\\Modules\\".ucfirst($module)."\\ModuleProvider";
            if(class_exists($moduleClass))
            {
                $gateway = call_user_func([$moduleClass,'getPaymentGateway']);
                if(!empty($gateway)){
                    $gateways = array_merge($gateways,$gateway);
                }
            }
        }
    }
    //Plugin
    $plugin_modules = \Plugins\ServiceProvider::getModules();
    if(!empty($plugin_modules)){
        foreach($plugin_modules as $module){
            $moduleClass = "\\Plugins\\".ucfirst($module)."\\ModuleProvider";
            if(class_exists($moduleClass))
            {
                $gateway = call_user_func([$moduleClass,'getPaymentGateway']);
                if(!empty($gateway)){
                    $gateways = array_merge($gateways,$gateway);
                }
            }
        }
    }

    foreach ($gateways as $id=>$class){
        $gateways[$id] = get_class(app()->make($class));
    }
    return $gateways;
}

function get_current_currency($need,$default = '')
{
    return Currency::getCurrent($need,$default);
}

function booking_status_to_text($status)
{
    switch ($status){
        case "draft":
            return __('Draft');
            break;
        case "unpaid":
            return __('Unpaid');
            break;
        case "paid":
            return __('Paid');
            break;
        case "processing":
            return __('Processing');
            break;
        case "completed":
            return __('Completed');
            break;
        case "confirmed":
            return __('Confirmed');
            break;
        case "cancelled":
            return __('Cancelled');
            break;
        case "cancel":
            return __('Cancel');
            break;
        case "pending":
            return __('Pending');
            break;
        case "partial_payment":
            return __('Partial Payment');
            break;
        case "fail":
            return __('Failed');
            break;
        default:
            return ucfirst($status ?? '');
            break;
    }
}
function verify_type_to($type,$need = 'name')
{
    switch ($type){
        case "phone":
            return __("Phone");
            break;
        case "number":
            return __("Number");
            break;
        case "email":
            return __("Email");
            break;
        case "file":
            return __("Attachment");
            break;
        case "multi_files":
            return __("Multi Attachments");
            break;
        case "text":
        default:
            return __("Text");
            break;
    }
}

function get_all_verify_fields(){
    return setting_item_array('role_verify_fields');
}
/*Hook Functions*/
function add_action($hook, $callback, $priority = 20, $arguments = 1){
    return \Modules\Core\Facades\Hook::addAction($hook, $callback, $priority, $arguments);
}
function add_filter($hook, $callback, $priority = 20, $arguments = 1){
    return \Modules\Core\Facades\Hook::addFilter($hook, $callback, $priority, $arguments);
}
function do_action(){
    return \Modules\Core\Facades\Hook::action(...func_get_args());
}
function apply_filters(){
    return \Modules\Core\Facades\Hook::filter(...func_get_args());
}
function is_installed(){
    return file_exists(storage_path('installed'));
}
function is_enable_multi_lang(){
    return (bool) setting_item('site_enable_multi_lang');
}

function is_enable_language_route(){
    return (is_installed() and is_enable_multi_lang() and app()->getLocale() != setting_item('site_locale'));
}

function duration_format($hour,$is_full = false)
{
    $day = floor($hour / 24) ;
    $hour = $hour % 24;
    $tmp = '';

    if($day) $tmp = $day.__('D');

    if($hour)
    $tmp .= $hour.__('H');

    if($is_full){
        $tmp = [];
        if($day){
            if($day > 1){
                $tmp[] = __(':count Days',['count'=>$day]);
            }else{
                $tmp[] = __(':count Day',['count'=>$day]);
            }
        }
        if($hour){
            if($hour > 1){
                $tmp[] = __(':count Hours',['count'=>$hour]);
            }else{
                $tmp[] = __(':count Hour',['count'=>$hour]);
            }
        }

        $tmp = implode(' ',$tmp);
    }

    return $tmp;
}
function is_enable_guest_checkout(){
    return setting_item('booking_guest_checkout');
}

function handleVideoUrl($string,$video_id = false)
{
    if($video_id && !empty($string)){
        parse_str( parse_url( $string, PHP_URL_QUERY ), $values );
        return $values['v'];
    }
    if (strpos($string, 'youtu') !== false) {
        preg_match("#(?<=v=)[a-zA-Z0-9-]+(?=&)|(?<=v\/)[^&\n]+|(?<=v=)[^&\n]+|(?<=youtu.be/)[^&\n]+#", $string, $matches);
        if (!empty($matches[0])) return "https://www.youtube.com/embed/" . e($matches[0]);
    }
    return $string;
}

function is_api(){
    return request()->segment(1) == 'api';
}

function is_demo_mode(){
    return env('DEMO_MODE',false);
}
function credit_to_money($amount){
    return $amount * setting_item('wallet_credit_exchange_rate',1);
}

function money_to_credit($amount,$roundUp = false){
    $res = $amount / setting_item('wallet_credit_exchange_rate',1);

    if($roundUp) return ceil($res);

    return $res;
}

function clean_by_key($object, $keyIndex, $children = 'children'){
    if(is_string($object)){
        return clean($object);
    }

    if(is_array($object)){
        if(isset($object[$keyIndex])){
            $newClean = clean($object[$keyIndex]);
            $object[$keyIndex] =  $newClean;
            if(!empty($object[$children])){
                $object[$children] = clean_by_key($object[$children], $keyIndex);
            }

        }else{
            foreach($object as $key => $oneObject){
                if(isset($oneObject[$keyIndex])){
                    $newClean = clean($oneObject[$keyIndex]);
                    $object[$key][$keyIndex] =  $newClean;
                }

                if(!empty($oneObject[$children])){
                    $object[$key][$children] = clean_by_key($oneObject[$children], $keyIndex);
                }
            }
        }

        return $object;
    }
    return $object;
}
function periodDate($startDate,$endDate,$day = true,$interval='1 day'){
    $begin = new \DateTime($startDate);
    $end = new \DateTime($endDate);
    if($day){
        $end = $end->modify('+1 day');
    }
    $interval = \DateInterval::createFromDateString($interval);
    $period = new \DatePeriod($begin, $interval, $end);
    return $period;
}

function _fixTextScanTranslations(){
    return __("Show on the map");
}


function is_admin(){
    if(!auth()->check()) return false;
    if(auth()->user()->hasPermission('dashboard_access')) return true;
    return false;
}
function is_vendor(){
    if(!auth()->check()) return false;
    if(auth()->user()->hasPermission('dashboard_vendor_access')) return true;
    return false;
    }

function get_link_detail_services($services, $id,$action='edit'){
    if( \Route::has($services.'.admin.'.$action) ){
        return route($services.'.admin.'.$action, ['id' => $id]);
    }else{
        return '#';
    }

}

function get_link_vendor_detail_services($services, $id,$action='edit'){
    if( \Route::has($services.'.vendor.'.$action) ){
        return route($services.'.vendor.'.$action, ['id' => $id]);
    }else{
        return '#';
    }

}

function format_interval($d1, $d2 = ''){
    $first_date = new DateTime($d1);
    if(!empty($d2)){
        $second_date = new DateTime($d2);
    }else{
        $second_date = new DateTime();
    }


    $interval = $first_date->diff($second_date);

    $result = "";
    if ($interval->y) { $result .= $interval->format("%y years "); }
    if ($interval->m) { $result .= $interval->format("%m months "); }
    if ($interval->d) { $result .= $interval->format("%d days "); }
    if ($interval->h) { $result .= $interval->format("%h hours "); }
    if ($interval->i) { $result .= $interval->format("%i minutes "); }
    if ($interval->s) { $result .= $interval->format("%s seconds "); }

    return $result;
}
function generate_timezone_list()
    {
        static $regions = array(
            DateTimeZone::AFRICA,
            DateTimeZone::AMERICA,
            DateTimeZone::ANTARCTICA,
            DateTimeZone::ASIA,
            DateTimeZone::ATLANTIC,
            DateTimeZone::AUSTRALIA,
            DateTimeZone::EUROPE,
            DateTimeZone::INDIAN,
            DateTimeZone::PACIFIC,
        );

        $timezones = array();
        foreach( $regions as $region )
        {
            $timezones = array_merge( $timezones, DateTimeZone::listIdentifiers( $region ) );
        }

        $timezone_offsets = array();
        foreach( $timezones as $timezone )
        {
            $tz = new DateTimeZone($timezone);
            $timezone_offsets[$timezone] = $tz->getOffset(new DateTime);
        }

        // sort timezone by offset
        asort($timezone_offsets);

        $timezone_list = array();
        foreach( $timezone_offsets as $timezone => $offset )
        {
            $offset_prefix = $offset < 0 ? '-' : '+';
            $offset_formatted = gmdate( 'H:i', abs($offset) );

            $pretty_offset = "UTC${offset_prefix}${offset_formatted}";

            $timezone_list[$timezone] = "$timezone (${pretty_offset})";
        }

        return $timezone_list;
    }

    function is_string_match($string,$wildcard){
        $pattern = preg_quote($wildcard,'/');
        $pattern = str_replace( '\*' , '.*', $pattern);
        return preg_match( '/^' . $pattern . '$/i' , $string );
    }
    function getNotify()
    {
        $checkNotify = \Modules\Core\Models\NotificationPush::query();
        if(is_admin()){
            $checkNotify->where(function($query){
                $query->where('for_admin',1);
                $query->orWhere('notifiable_id', Auth::id());
            });
        }else{
            $checkNotify->where('for_admin',0);
            $checkNotify->where('notifiable_id', Auth::id());
        }
        $notifications = $checkNotify->orderBy('created_at', 'desc')->limit(5)->get();
        $countUnread = $checkNotify->where('read_at', null)->count();
        return [$notifications,$countUnread];
    }

    function is_enable_registration(){
        return !setting_item('user_disable_register');
    }
    function is_enable_vendor_team(){
        return false;
        return setting_item('vendor_team_enable');
    }

    function is_enable_plan(){
        return setting_item('user_plans_enable') == true;
    }

    function get_main_lang(){
        return setting_item('site_locale');
    }

    function is_compatible($current,$list_to_check){
        if(in_array($current,$list_to_check)) return true;
        foreach ($list_to_check as $v){
            if(version_compare($current,$v) >= 0) return true;
        }
        return false;
    }

if (!function_exists('external_url')) {
    function external_url(?string $url): ?string
    {
        $url = trim((string) $url);
        if ($url === '' || $url === '0') {
            return null;
        }
        if (!preg_match('#^https?://#i', $url)) {
            $url = 'https://' . ltrim($url, '/');
        }
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return null;
        }

        return $url;
    }
}

if (!function_exists('bookable_external_url')) {
    function bookable_external_url($service, string $field): ?string
    {
        if (!is_object($service)) {
            return null;
        }

        $url = $service->{$field} ?? null;
        if ($field === 'website' && empty(trim((string) $url)) && !empty($service->author)) {
            $url = $service->author->website ?? null;
        }

        return external_url($url);
    }
}
